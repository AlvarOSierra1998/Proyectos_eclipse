package programass;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class bienvenido extends JFrame {

	private JPanel bienvenido;
	private JTable table;
	private ClassBBDD user = new ClassBBDD();
	private JTextField contraseñatxt;
	private JTextField nombretxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bienvenido frame = new bienvenido();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bienvenido() {
		setTitle("BIENVENIDO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 855, 846);
		bienvenido = new JPanel();
		bienvenido.setBackground(Color.BLACK);
		bienvenido.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(bienvenido);
		bienvenido.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("BIENVENIDO VIAJERO!");
		lblNewLabel_1.setFont(new Font("OptimusPrincepsSemiBold", Font.PLAIN, 28));
		lblNewLabel_1.setForeground(Color.ORANGE);
		lblNewLabel_1.setBounds(253, 61, 337, 155);
		bienvenido.add(lblNewLabel_1);
		
		table = new JTable();
		table.setForeground(Color.ORANGE);
		table.setBackground(Color.BLACK);
		table.setBounds(79, 182, 681, 210);
		table.setModel(user.rellenarTablapersonajes());
		bienvenido.add(table);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon(bienvenido.class.getResource("/IMAGENES/loading.gif")));
		lblNewLabel.setBounds(301, 254, 528, 553);
		bienvenido.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("BORRAR");
		btnNewButton.setBounds(79, 614, 130, 40);
		bienvenido.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("COMPROBAR");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(user.seleccionDeDato(nombretxt.getText(), contraseñatxt.getText())) {
					JOptionPane.showMessageDialog(bienvenido, "Se encuentra registrado ", "ta bien",
							JOptionPane.INFORMATION_MESSAGE);
					
				}else {
					JOptionPane.showMessageDialog(bienvenido, "no ta bien  DATA", "THE FORM IS EMPTY",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_1.setBounds(79, 550, 130, 40);
		bienvenido.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("Contraseña");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setForeground(new Color(255, 200, 0));
		lblNewLabel_2.setBounds(10, 479, 142, 27);
		bienvenido.add(lblNewLabel_2);
		
		contraseñatxt = new JTextField();
		contraseñatxt.setBounds(128, 479, 182, 27);
		bienvenido.add(contraseñatxt);
		contraseñatxt.setColumns(10);
		
		nombretxt = new JTextField();
		nombretxt.setColumns(10);
		nombretxt.setBounds(107, 441, 130, 27);
		bienvenido.add(nombretxt);
		
		JLabel lblNewLabel_3 = new JLabel("Nombre");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setForeground(Color.ORANGE);
		lblNewLabel_3.setBounds(10, 438, 96, 25);
		bienvenido.add(lblNewLabel_3);
	}
}
