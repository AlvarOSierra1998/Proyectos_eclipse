package programass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;

public class ClassBBDD {
	Conexion conexion = new Conexion();
	Connection conex = null;
	Statement stat = null;
	ResultSet rs = null;
	PreparedStatement stm22;

	// AGREGAR USUARIO
	public void AgregarUsuario(String usuario, String contraseña, String email) {
		try {
			conex = conexion.conectar();
			PreparedStatement stm2 = conex
					.prepareStatement("INSERT INTO usuario(Usuario,Contraseña,Email) VALUES (?,?,?)");

			stm2.setString(1, usuario);
			stm2.setString(2, contraseña);
			stm2.setString(3, email);

			stm2.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stat != null) {
					stat.close();
				}

				if (conex != null) {
					conex.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	// MODIFICAR CONTRASEÑA
	public void modificarDatosCONTRASEÑA(String contraseña, String Usuario) {
		try {
			conex = conexion.conectar();
			PreparedStatement stat3 = conex.prepareStatement("UPDATE usuario SET Contraseña = ? WHERE Usuario = ?");
			stat3.setString(1, "contraseña");
			stat3.setString(2, "usuario");
			stat3.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stat != null) {
					stat.close();
				}

				if (conex != null) {
					conex.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

	// MODIFICAR TODOS LOS DATOS
	public void modificarDatosTodal(String Usuario, String contraseña, String email, String clase) {
		try {
			conex = conexion.conectar();
			PreparedStatement stat3 = conex.prepareStatement(
					"UPDATE usuario SET usuario = ?, SET CONTRASEÑA = ?, SET EMAIL = ?, SET CLASE= ? WHERE Usuario = ?");
			stat3.setString(1, "Usuario");
			stat3.setString(2, "contraseña");
			stat3.setString(3, "email");
			stat3.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stat != null) {
					stat.close();
				}

				if (conex != null) {
					conex.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

	public void BorrarDatos(String Usuario) {
		try {
			conex = conexion.conectar();
			PreparedStatement stat4 = conex.prepareStatement("DELETE FROM usuario  WHERE ID = ?");
			stat4.setString(1, "Usuario");
			stat4.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stat != null) {
					stat.close();
				}

				if (conex != null) {
					conex.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public boolean seleccionDeDato(String usuario, String Contraseña) {
		boolean resultado = false;
		try {
			conex = conexion.conectar();
			PreparedStatement stat4 = conex.prepareStatement("SELECT COUNT(*) FROM usuario WHERE Usuario = ? AND contraseña= ? ");
			stat4.setString(1, usuario);
			stat4.setString(2, Contraseña);
			rs= stat4.executeQuery();
		
			
			if( rs.next() && rs.getInt(1) == 1 ) {
				resultado = true ;
				System.out.println("Esta en BD");
			}
			System.out.println(rs.getInt(1) );
			

		} catch (SQLException e) {
			
			e.printStackTrace();

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stat != null) {
					stat.close();
				}

				if (conex != null) {
					conex.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return resultado;

	}
	
	public DefaultTableModel rellenarTablapersonajes() {
        String[] columnas = { "id", "Usuario", "contraseña", "email"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        try {
            String consulta = "SELECT id, Usuario, contraseña,email FROM usuario";
            conex = conexion.conectar();
             stm22 = conex.prepareStatement(consulta);
            rs = stm22.executeQuery(consulta);
            modelo.addRow(columnas);
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("Usuario");
                String contraseña = rs.getString("contraseña");
                String email = rs.getString("email");
                
                Object[] fila = { id, nombre, contraseña, email };
                modelo.addRow(fila);
            }

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (stm22 != null) {
                	stm22 .close();
                }

                if (conex != null) {
                	conex.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return modelo;
    }
}
